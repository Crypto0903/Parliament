president_data = {
    "name": "",
    "term_start": "",
    "term_length": 0
}

def president_menu():
    while True:
        print("\nPresident Menu:")
        print("1. Create President")
        print("2. Display Info")
        print("3. Appoint Prime Minister")
        print("4. Sign Bill into Law")
        print("5. Declare Emergency")
        print("6. Address Nation")
        print("7. Back to Main Menu")
        sub_choice = int(input("Enter your choice: "))

        if sub_choice == 1:
            president_data["name"] = input("Enter president name: ")
            president_data["term_start"] = input("Enter term start: ")
            president_data["term_length"] = int(input("Enter term length (years): "))
        elif sub_choice == 2:
            if president_data["name"]:
                print(f"President: {president_data['name']}")
                print(f"Term Start: {president_data['term_start']}")
                print(f"Term Length: {president_data['term_length']} years")
            else:
                print("No president object created yet.")
        elif sub_choice == 3:
            if president_data["name"]:
                pm_name = input("Enter Prime Minister name: ")
                print(f"The President has appointed {pm_name} as the Prime Minister.")
            else:
                print("No president object created yet.")
        elif sub_choice == 4:
            if president_data["name"]:
                bill_name = input("Enter bill name: ")
                print(f"The President has signed the bill '{bill_name}' into law.")
            else:
                print("No president object created yet.")
        elif sub_choice == 5:
            if president_data["name"]:
                print("The President has declared a state of emergency.")
            else:
                print("No president object created yet.")
        elif sub_choice == 6:
            if president_data["name"]:
                message = input("Enter message: ")
                print(f"The President's address to the nation: {message}")
            else:
                print("No president object created yet.")
        elif sub_choice == 7:
            break
        else:
            print("Invalid choice. Please try again.")
