rajya_sabha_data = {
    "number_of_members": 0,
    "chairman_name": "",
    "members": []
}

def rajya_sabha_menu(COUNTRY):
    while True:
        print("\nRajya Sabha Menu:")
        print("1. Create Rajya Sabha")
        print("2. Display Info")
        print("3. Pass Bill")
        print("4. Debate")
        print("5. Adjourn Session")
        print("6. Add Member")
        print("7. Back to Main Menu")
        sub_choice = int(input("Enter your choice: "))

        if sub_choice == 1:
            rajya_sabha_data["number_of_members"] = int(input("Enter number of members: "))
            rajya_sabha_data["chairman_name"] = input("Enter chairman name: ")
            rajya_sabha_data["members"] = []
        elif sub_choice == 2:
            if rajya_sabha_data["number_of_members"] > 0:
                print(f"Country: {COUNTRY}")
                print(f"Number of Members: {rajya_sabha_data['number_of_members']}")
                print(f"Rajya Sabha Chairman: {rajya_sabha_data['chairman_name']}")
                print("Members:")
                for mp in rajya_sabha_data["members"]:
                    print(f"MP Name: {mp['name']}")
                    print(f"Constituency: {mp['constituency']}")
                    print(f"Party: {mp['party']}")
            else:
                print("No Rajya Sabha object created yet.")
        elif sub_choice == 3:
            if rajya_sabha_data["number_of_members"] > 0:
                bill_name = input("Enter bill name: ")
                print(f"The bill '{bill_name}' has been passed by the Parliament.")
            else:
                print("No Rajya Sabha object created yet.")
        elif sub_choice == 4:
            if rajya_sabha_data["number_of_members"] > 0:
                topic = input("Enter debate topic: ")
                print(f"Debate on the topic: {topic} is in progress in the Parliament.")
            else:
                print("No Rajya Sabha object created yet.")
        elif sub_choice == 5:
            if rajya_sabha_data["number_of_members"] > 0:
                print("The Parliament session has been adjourned.")
            else:
                print("No Rajya Sabha object created yet.")
        elif sub_choice == 6:
            if rajya_sabha_data["number_of_members"] > 0:
                if len(rajya_sabha_data["members"]) < rajya_sabha_data["number_of_members"]:
                    name = input("Enter MP name: ")
                    constituency = input("Enter constituency: ")
                    party = input("Enter party: ")
                    mp = {"name": name, "constituency": constituency, "party": party}
                    rajya_sabha_data["members"].append(mp)
                else:
                    print("Rajya Sabha is full.")
            else:
                print("No Rajya Sabha object created yet.")
        elif sub_choice == 7:
            break
        else:
            print("Invalid choice. Please try again.")
