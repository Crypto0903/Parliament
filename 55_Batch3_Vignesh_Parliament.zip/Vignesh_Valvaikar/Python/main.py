import lok_sabha
import rajya_sabha
import president

COUNTRY = "India"

while True:
    print("Main Menu:")
    print("1. Lok Sabha Menu")
    print("2. Rajya Sabha Menu")
    print("3. President Menu")
    print("4. Exit")
    choice = int(input("Enter your choice: "))
    
    if choice == 1:
        lok_sabha.lok_sabha_menu(COUNTRY)
    elif choice == 2:
        rajya_sabha.rajya_sabha_menu(COUNTRY)
    elif choice == 3:
        president.president_menu()
    elif choice == 4:
        print("Exiting...")
        break
    else:
        print("Invalid choice. Please try again.")
