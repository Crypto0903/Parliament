lok_sabha_data = {
    "number_of_members": 0,
    "speaker_name": "",
    "members": []
}

def lok_sabha_menu(COUNTRY):
    while True:
        print("\nLok Sabha Menu:")
        print("1. Create Lok Sabha")
        print("2. Display Info")
        print("3. Pass Bill")
        print("4. Debate")
        print("5. Adjourn Session")
        print("6. Add Member")
        print("7. Back to Main Menu")
        sub_choice = int(input("Enter your choice: "))

        if sub_choice == 1:
            lok_sabha_data["number_of_members"] = int(input("Enter number of members: "))
            lok_sabha_data["speaker_name"] = input("Enter speaker name: ")
            lok_sabha_data["members"] = []
        elif sub_choice == 2:
            if lok_sabha_data["number_of_members"] > 0:
                print(f"Country: {COUNTRY}")
                print(f"Number of Members: {lok_sabha_data['number_of_members']}")
                print(f"Lok Sabha Speaker: {lok_sabha_data['speaker_name']}")
                print("Members:")
                for mp in lok_sabha_data["members"]:
                    print(f"MP Name: {mp['name']}")
                    print(f"Constituency: {mp['constituency']}")
                    print(f"Party: {mp['party']}")
            else:
                print("No Lok Sabha object created yet.")
        elif sub_choice == 3:
            if lok_sabha_data["number_of_members"] > 0:
                bill_name = input("Enter bill name: ")
                print(f"The bill '{bill_name}' has been passed by the Parliament.")
            else:
                print("No Lok Sabha object created yet.")
        elif sub_choice == 4:
            if lok_sabha_data["number_of_members"] > 0:
                topic = input("Enter debate topic: ")
                print(f"Debate on the topic: {topic} is in progress in the Parliament.")
            else:
                print("No Lok Sabha object created yet.")
        elif sub_choice == 5:
            if lok_sabha_data["number_of_members"] > 0:
                print("The Parliament session has been adjourned.")
            else:
                print("No Lok Sabha object created yet.")
        elif sub_choice == 6:
            if lok_sabha_data["number_of_members"] > 0:
                if len(lok_sabha_data["members"]) < lok_sabha_data["number_of_members"]:
                    name = input("Enter MP name: ")
                    constituency = input("Enter constituency: ")
                    party = input("Enter party: ")
                    mp = {"name": name, "constituency": constituency, "party": party}
                    lok_sabha_data["members"].append(mp)
                else:
                    print("Lok Sabha is full.")
            else:
                print("No Lok Sabha object created yet.")
        elif sub_choice == 7:
            break
        else:
            print("Invalid choice. Please try again.")
