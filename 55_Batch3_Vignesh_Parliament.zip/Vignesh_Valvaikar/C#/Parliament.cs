using System;
using System.Collections.Generic;

public class MP
{
    public string Name { get; set; }
    public string Constituency { get; set; }
    public string Party { get; set; }

    public MP(string name, string constituency, string party)
    {
        Name = name;
        Constituency = constituency;
        Party = party;
    }

    public void DisplayInfo()
    {
        Console.WriteLine($"MP Name: {Name}");
        Console.WriteLine($"Constituency: {Constituency}");
        Console.WriteLine($"Party: {Party}");
    }
}

public class Parliament
{
    protected const string COUNTRY = "India";
    public int NumberOfMembers { get; set; }

    public Parliament(int numberOfMembers)
    {
        NumberOfMembers = numberOfMembers;
    }

    public virtual void DisplayInfo()
    {
        Console.WriteLine($"Country: {COUNTRY}");
        Console.WriteLine($"Number of Members: {NumberOfMembers}");
    }

    public virtual void PassBill(string billName)
    {
        Console.WriteLine($"The bill '{billName}' has been passed by the Parliament.");
    }

    public virtual void Debate(string topic)
    {
        Console.WriteLine($"Debate on the topic: {topic} is in progress in the Parliament.");
    }

    public virtual void AdjournSession()
    {
        Console.WriteLine("The Parliament session has been adjourned.");
    }
}

public class LokSabha : Parliament
{
    public string SpeakerName { get; set; }
    private List<MP> members;

    public LokSabha(int numberOfMembers, string speakerName) : base(numberOfMembers)
    {
        SpeakerName = speakerName;
        members = new List<MP>();
    }

    public void AddMember(MP mp)
    {
        if (members.Count < NumberOfMembers)
        {
            members.Add(mp);
        }
        else
        {
            Console.WriteLine("Lok Sabha is full.");
        }
    }

    public override void DisplayInfo()
    {
        base.DisplayInfo();
        Console.WriteLine($"Lok Sabha Speaker: {SpeakerName}");
        Console.WriteLine("Members:");
        foreach (var mp in members)
        {
            mp.DisplayInfo();
        }
    }
}

public class RajyaSabha : Parliament
{
    public string ChairmanName { get; set; }
    private List<MP> members;

    public RajyaSabha(int numberOfMembers, string chairmanName) : base(numberOfMembers)
    {
        ChairmanName = chairmanName;
        members = new List<MP>();
    }

    public void AddMember(MP mp)
    {
        if (members.Count < NumberOfMembers)
        {
            members.Add(mp);
        }
        else
        {
            Console.WriteLine("Rajya Sabha is full.");
        }
    }

    public override void DisplayInfo()
    {
        base.DisplayInfo();
        Console.WriteLine($"Rajya Sabha Chairman: {ChairmanName}");
        Console.WriteLine("Members:");
        foreach (var mp in members)
        {
            mp.DisplayInfo();
        }
    }
}

public class President
{
    public string Name { get; set; }
    public string TermStart { get; set; }
    public int TermLength { get; set; }

    public President(string name, string termStart, int termLength)
    {
        Name = name;
        TermStart = termStart;
        TermLength = termLength;
    }

    public void DisplayInfo()
    {
        Console.WriteLine($"President: {Name}");
        Console.WriteLine($"Term Start: {TermStart}");
        Console.WriteLine($"Term Length: {TermLength} years");
    }

    public void AppointPrimeMinister(string primeMinisterName)
    {
        Console.WriteLine($"The President has appointed {primeMinisterName} as the Prime Minister.");
    }

    public void SignBill(string billName)
    {
        Console.WriteLine($"The President has signed the bill '{billName}' into law.");
    }

    public void DeclareEmergency()
    {
        Console.WriteLine("The President has declared a state of emergency.");
    }

    public void AddressNation(string message)
    {
        Console.WriteLine($"The President's address to the nation: {message}");
    }
}

public class Program
{
    public static void LokSabhaMenu(ref LokSabha lokSabha)
    {
        int choice;
        do
        {
            Console.WriteLine("\nLok Sabha Menu:");
            Console.WriteLine("1. Create Lok Sabha");
            Console.WriteLine("2. Display Info");
            Console.WriteLine("3. Pass Bill");
            Console.WriteLine("4. Debate");
            Console.WriteLine("5. Adjourn Session");
            Console.WriteLine("6. Add Member");
            Console.WriteLine("7. Back to Main Menu");
            Console.Write("Enter your choice: ");
            choice = int.Parse(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    {
                        Console.Write("Enter number of members: ");
                        int numberOfMembers = int.Parse(Console.ReadLine());
                        Console.Write("Enter speaker name: ");
                        string speakerName = Console.ReadLine();
                        lokSabha = new LokSabha(numberOfMembers, speakerName);
                        break;
                    }
                case 2:
                    lokSabha?.DisplayInfo();
                    break;
                case 3:
                    {
                        Console.Write("Enter bill name: ");
                        string billName = Console.ReadLine();
                        lokSabha?.PassBill(billName);
                        break;
                    }
                case 4:
                    {
                        Console.Write("Enter debate topic: ");
                        string topic = Console.ReadLine();
                        lokSabha?.Debate(topic);
                        break;
                    }
                case 5:
                    lokSabha?.AdjournSession();
                    break;
                case 6:
                    {
                        Console.Write("Enter MP name: ");
                        string name = Console.ReadLine();
                        Console.Write("Enter constituency: ");
                        string constituency = Console.ReadLine();
                        Console.Write("Enter party: ");
                        string party = Console.ReadLine();
                        MP mp = new MP(name, constituency, party);
                        lokSabha?.AddMember(mp);
                        break;
                    }
                case 7:
                    Console.WriteLine("Returning to Main Menu...");
                    break;
                default:
                    Console.WriteLine("Invalid choice. Please try again.");
                    break;
            }
        } while (choice != 7);
    }

    public static void RajyaSabhaMenu(ref RajyaSabha rajyaSabha)
    {
        int choice;
        do
        {
            Console.WriteLine("\nRajya Sabha Menu:");
            Console.WriteLine("1. Create Rajya Sabha");
            Console.WriteLine("2. Display Info");
            Console.WriteLine("3. Pass Bill");
            Console.WriteLine("4. Debate");
            Console.WriteLine("5. Adjourn Session");
            Console.WriteLine("6. Add Member");
            Console.WriteLine("7. Back to Main Menu");
            Console.Write("Enter your choice: ");
            choice = int.Parse(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    {
                        Console.Write("Enter number of members: ");
                        int numberOfMembers = int.Parse(Console.ReadLine());
                        Console.Write("Enter chairman name: ");
                        string chairmanName = Console.ReadLine();
                        rajyaSabha = new RajyaSabha(numberOfMembers, chairmanName);
                        break;
                    }
                case 2:
                    rajyaSabha?.DisplayInfo();
                    break;
                case 3:
                    {
                        Console.Write("Enter bill name: ");
                        string billName = Console.ReadLine();
                        rajyaSabha?.PassBill(billName);
                        break;
                    }
                case 4:
                    {
                        Console.Write("Enter debate topic: ");
                        string topic = Console.ReadLine();
                        rajyaSabha?.Debate(topic);
                        break;
                    }
                case 5:
                    rajyaSabha?.AdjournSession();
                    break;
                case 6:
                    {
                        Console.Write("Enter MP name: ");
                        string name = Console.ReadLine();
                        Console.Write("Enter constituency: ");
                        string constituency = Console.ReadLine();
                        Console.Write("Enter party: ");
                        string party = Console.ReadLine();
                        MP mp = new MP(name, constituency, party);
                        rajyaSabha?.AddMember(mp);
                        break;
                    }
                case 7:
                    Console.WriteLine("Returning to Main Menu...");
                    break;
                default:
                    Console.WriteLine("Invalid choice. Please try again.");
                    break;
            }
        } while (choice != 7);
    }

    public static void PresidentMenu(ref President president)
    {
        int choice;
        do
        {
            Console.WriteLine("\nPresident Menu:");
            Console.WriteLine("1. Create President");
            Console.WriteLine("2. Display Info");
            Console.WriteLine("3. Appoint Prime Minister");
            Console.WriteLine("4. Sign Bill into Law");
            Console.WriteLine("5. Declare Emergency");
            Console.WriteLine("6. Address Nation");
            Console.WriteLine("7. Back to Main Menu");
            Console.Write("Enter your choice: ");
            choice = int.Parse(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    {
                        Console.Write("Enter president name: ");
                        string name = Console.ReadLine();
                        Console.Write("Enter term start: ");
                        string termStart = Console.ReadLine();
                        Console.Write("Enter term length (years): ");
                        int termLength = int.Parse(Console.ReadLine());
                        president = new President(name, termStart, termLength);
                        break;
                    }
                case 2:
                    president?.DisplayInfo();
                    break;
                case 3:
                    {
                        Console.Write("Enter Prime Minister name: ");
                        string pmName = Console.ReadLine();
                        president?.AppointPrimeMinister(pmName);
                        break;
                    }
                case 4:
                    {
                        Console.Write("Enter bill name: ");
                        string billName = Console.ReadLine();
                        president?.SignBill(billName);
                        break;
                    }
                case 5:
                    president?.DeclareEmergency();
                    break;
                case 6:
                    {
                        Console.Write("Enter message: ");
                        string message = Console.ReadLine();
                        president?.AddressNation(message);
                        break;
                    }
                case 7:
                    Console.WriteLine("Returning to Main Menu...");
                    break;
                default:
                    Console.WriteLine("Invalid choice. Please try again.");
                    break;
            }
        } while (choice != 7);
    }

    public static void Main()
    {
        LokSabha lokSabha = null;
        RajyaSabha rajyaSabha = null;
        President president = null;

        int choice;
        do
        {
            Console.WriteLine("\nMain Menu:");
            Console.WriteLine("1. Lok Sabha Menu");
            Console.WriteLine("2. Rajya Sabha Menu");
            Console.WriteLine("3. President Menu");
            Console.WriteLine("4. Exit");
            Console.Write("Enter your choice: ");
            choice = int.Parse(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    LokSabhaMenu(ref lokSabha);
                    break;
                case 2:
                    RajyaSabhaMenu(ref rajyaSabha);
                    break;
                case 3:
                    PresidentMenu(ref president);
                    break;
                case 4:
                    Console.WriteLine("Exiting...");
                    break;
                default:
                    Console.WriteLine("Invalid choice. Please try again.");
                    break;
            }
        } while (choice != 4);
    }
}
