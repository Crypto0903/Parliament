/*Author: Vignesh Sudhan Valvaikar
Roll no: 54
Start Date:
Modified Date: 23/07/2024
*/

import java.util.ArrayList;
import java.util.List;

public class LokSabha extends Parliament {
    private String speakerName;
    private List<MP> members;

    public LokSabha(int numberOfMembers, String speakerName) {
        super(numberOfMembers);
        this.speakerName = speakerName;
        this.members = new ArrayList<>();
    }

    public String getSpeakerName() {
        return speakerName;
    }

    public void setSpeakerName(String speakerName) {
        this.speakerName = speakerName;
    }

    public void addMember(MP mp) {
        if (members.size() < getNumberOfMembers()) { // Use getNumberOfMembers() to access the parent class variable
            members.add(mp);
        } else {
            System.out.println("Lok Sabha is full.");
        }
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Lok Sabha Speaker: " + speakerName);
        System.out.println("Members:");
        for (MP mp : members) {
            mp.displayInfo();
        }
    }
}
