/*Author: Vignesh Sudhan Valvaikar
Roll no: 54
Start Date:
Modified Date: 23/07/2024
*/

public class Parliament {
    private static final String COUNTRY = "India";
    private int numberOfMembers;

    public Parliament(int numberOfMembers) {
        this.numberOfMembers = numberOfMembers;
    }

    public int getNumberOfMembers() {
        return numberOfMembers;
    }

    public void setNumberOfMembers(int numberOfMembers) {
        this.numberOfMembers = numberOfMembers;
    }

    public void displayInfo() {
        System.out.println("Country: " + COUNTRY);
        System.out.println("Number of Members: " + numberOfMembers);
    }

    public void passBill(String billName) {
        System.out.println("The bill '" + billName + "' has been passed by the Parliament.");
    }

    public void debate(String topic) {
        System.out.println("Debate on the topic: " + topic + " is in progress in the Parliament.");
    }

    public void adjournSession() {
        System.out.println("The Parliament session has been adjourned.");
    }
}
