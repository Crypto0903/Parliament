#include <iostream>
#include <vector>
#include <string>

using namespace std;

class MP {
public:
    string name;
    string constituency;
    string party;

    MP(const string &name, const string &constituency, const string &party)
        : name(name), constituency(constituency), party(party) {}

    void displayInfo() const {
        cout << "MP Name: " << name << endl;
        cout << "Constituency: " << constituency << endl;
        cout << "Party: " << party << endl;
    }
};

class Parliament {
protected:
    static const string COUNTRY;
    int numberOfMembers;

public:
    Parliament(int numberOfMembers) : numberOfMembers(numberOfMembers) {}

    virtual void displayInfo() const {
        cout << "Country: " << COUNTRY << endl;
        cout << "Number of Members: " << numberOfMembers << endl;
    }

    virtual void passBill(const string &billName) const {
        cout << "The bill '" << billName << "' has been passed by the Parliament." << endl;
    }

    virtual void debate(const string &topic) const {
        cout << "Debate on the topic: " << topic << " is in progress in the Parliament." << endl;
    }

    virtual void adjournSession() const {
        cout << "The Parliament session has been adjourned." << endl;
    }
};

const string Parliament::COUNTRY = "India";

class LokSabha : public Parliament {
private:
    string speakerName;
    vector<MP> members;

public:
    LokSabha(int numberOfMembers, const string &speakerName)
        : Parliament(numberOfMembers), speakerName(speakerName) {}

    void addMember(const MP &mp) {
        if (members.size() < numberOfMembers) {
            members.push_back(mp);
        } else {
            cout << "Lok Sabha is full." << endl;
        }
    }

    void displayInfo() const override {
        Parliament::displayInfo();
        cout << "Lok Sabha Speaker: " << speakerName << endl;
        cout << "Members:" << endl;
        for (const auto &mp : members) {
            mp.displayInfo();
        }
    }
};

class RajyaSabha : public Parliament {
private:
    string chairmanName;
    vector<MP> members;

public:
    RajyaSabha(int numberOfMembers, const string &chairmanName)
        : Parliament(numberOfMembers), chairmanName(chairmanName) {}

    void addMember(const MP &mp) {
        if (members.size() < numberOfMembers) {
            members.push_back(mp);
        } else {
            cout << "Rajya Sabha is full." << endl;
        }
    }

    void displayInfo() const override {
        Parliament::displayInfo();
        cout << "Rajya Sabha Chairman: " << chairmanName << endl;
        cout << "Members:" << endl;
        for (const auto &mp : members) {
            mp.displayInfo();
        }
    }
};

class President {
private:
    string name;
    string termStart;
    int termLength;

public:
    President(const string &name, const string &termStart, int termLength)
        : name(name), termStart(termStart), termLength(termLength) {}

    void displayInfo() const {
        cout << "President: " << name << endl;
        cout << "Term Start: " << termStart << endl;
        cout << "Term Length: " << termLength << " years" << endl;
    }

    void appointPrimeMinister(const string &primeMinisterName) const {
        cout << "The President has appointed " << primeMinisterName << " as the Prime Minister." << endl;
    }

    void signBill(const string &billName) const {
        cout << "The President has signed the bill '" << billName << "' into law." << endl;
    }

    void declareEmergency() const {
        cout << "The President has declared a state of emergency." << endl;
    }

    void addressNation(const string &message) const {
        cout << "The President's address to the nation: " << message << endl;
    }
};

void lokSabhaMenu(LokSabha *&lokSabha) {
    int choice;
    do {
        cout << "\nLok Sabha Menu:" << endl;
        cout << "1. Create Lok Sabha" << endl;
        cout << "2. Display Info" << endl;
        cout << "3. Pass Bill" << endl;
        cout << "4. Debate" << endl;
        cout << "5. Adjourn Session" << endl;
        cout << "6. Add Member" << endl;
        cout << "7. Back to Main Menu" << endl;
        cout << "Enter your choice: ";
        cin >> choice;
        cin.ignore();
        switch (choice) {
            case 1: {
                int numberOfMembers;
                string speakerName;
                cout << "Enter number of members: ";
                cin >> numberOfMembers;
                cin.ignore();
                cout << "Enter speaker name: ";
                getline(cin, speakerName);
                delete lokSabha;  // Cleanup previous instance if exists
                lokSabha = new LokSabha(numberOfMembers, speakerName);
                break;
            }
            case 2:
                if (lokSabha) {
                    lokSabha->displayInfo();
                } else {
                    cout << "No Lok Sabha object created yet." << endl;
                }
                break;
            case 3:
                if (lokSabha) {
                    string billName;
                    cout << "Enter bill name: ";
                    getline(cin, billName);
                    lokSabha->passBill(billName);
                } else {
                    cout << "No Lok Sabha object created yet." << endl;
                }
                break;
            case 4:
                if (lokSabha) {
                    string topic;
                    cout << "Enter debate topic: ";
                    getline(cin, topic);
                    lokSabha->debate(topic);
                } else {
                    cout << "No Lok Sabha object created yet." << endl;
                }
                break;
            case 5:
                if (lokSabha) {
                    lokSabha->adjournSession();
                } else {
                    cout << "No Lok Sabha object created yet." << endl;
                }
                break;
            case 6:
                if (lokSabha) {
                    string name, constituency, party;
                    cout << "Enter MP name: ";
                    getline(cin, name);
                    cout << "Enter constituency: ";
                    getline(cin, constituency);
                    cout << "Enter party: ";
                    getline(cin, party);
                    MP mp(name, constituency, party);
                    lokSabha->addMember(mp);
                } else {
                    cout << "No Lok Sabha object created yet." << endl;
                }
                break;
            case 7:
                cout << "Returning to Main Menu..." << endl;
                break;
            default:
                cout << "Invalid choice. Please try again." << endl;
                break;
        }
    } while (choice != 7);
}

void rajyaSabhaMenu(RajyaSabha *&rajyaSabha) {
    int choice;
    do {
        cout << "\nRajya Sabha Menu:" << endl;
        cout << "1. Create Rajya Sabha" << endl;
        cout << "2. Display Info" << endl;
        cout << "3. Pass Bill" << endl;
        cout << "4. Debate" << endl;
        cout << "5. Adjourn Session" << endl;
        cout << "6. Add Member" << endl;
        cout << "7. Back to Main Menu" << endl;
        cout << "Enter your choice: ";
        cin >> choice;
        cin.ignore();
        switch (choice) {
            case 1: {
                int numberOfMembers;
                string chairmanName;
                cout << "Enter number of members: ";
                cin >> numberOfMembers;
                cin.ignore();
                cout << "Enter chairman name: ";
                getline(cin, chairmanName);
                delete rajyaSabha;  // Cleanup previous instance if exists
                rajyaSabha = new RajyaSabha(numberOfMembers, chairmanName);
                break;
            }
            case 2:
                if (rajyaSabha) {
                    rajyaSabha->displayInfo();
                } else {
                    cout << "No Rajya Sabha object created yet." << endl;
                }
                break;
            case 3:
                if (rajyaSabha) {
                    string billName;
                    cout << "Enter bill name: ";
                    getline(cin, billName);
                    rajyaSabha->passBill(billName);
                } else {
                    cout << "No Rajya Sabha object created yet." << endl;
                }
                break;
            case 4:
                if (rajyaSabha) {
                    string topic;
                    cout << "Enter debate topic: ";
                    getline(cin, topic);
                    rajyaSabha->debate(topic);
                } else {
                    cout << "No Rajya Sabha object created yet." << endl;
                }
                break;
            case 5:
                if (rajyaSabha) {
                    rajyaSabha->adjournSession();
                } else {
                    cout << "No Rajya Sabha object created yet." << endl;
                }
                break;
            case 6:
                if (rajyaSabha) {
                    string name, constituency, party;
                    cout << "Enter MP name: ";
                    getline(cin, name);
                    cout << "Enter constituency: ";
                    getline(cin, constituency);
                    cout << "Enter party: ";
                    getline(cin, party);
                    MP mp(name, constituency, party);
                    rajyaSabha->addMember(mp);
                } else {
                    cout << "No Rajya Sabha object created yet." << endl;
                }
                break;
            case 7:
                cout << "Returning to Main Menu..." << endl;
                break;
            default:
                cout << "Invalid choice. Please try again." << endl;
                break;
        }
    } while (choice != 7);
}

void presidentMenu(President *&president) {
    int choice;
    do {
        cout << "\nPresident Menu:" << endl;
        cout << "1. Create President" << endl;
        cout << "2. Display Info" << endl;
        cout << "3. Appoint Prime Minister" << endl;
        cout << "4. Sign Bill into Law" << endl;
        cout << "5. Declare Emergency" << endl;
        cout << "6. Address Nation" << endl;
        cout << "7. Back to Main Menu" << endl;
        cout << "Enter your choice: ";
        cin >> choice;
        cin.ignore();
        switch (choice) {
            case 1: {
                string name, termStart;
                int termLength;
                cout << "Enter president name: ";
                getline(cin, name);
                cout << "Enter term start: ";
                getline(cin, termStart);
                cout << "Enter term length (years): ";
                cin >> termLength;
                cin.ignore();
                delete president;  // Cleanup previous instance if exists
                president = new President(name, termStart, termLength);
                break;
            }
            case 2:
                if (president) {
                    president->displayInfo();
                } else {
                    cout << "No president object created yet." << endl;
                }
                break;
            case 3:
                if (president) {
                    string pmName;
                    cout << "Enter Prime Minister name: ";
                    getline(cin, pmName);
                    president->appointPrimeMinister(pmName);
                } else {
                    cout << "No president object created yet." << endl;
                }
                break;
            case 4:
                if (president) {
                    string billName;
                    cout << "Enter bill name: ";
                    getline(cin, billName);
                    president->signBill(billName);
                } else {
                    cout << "No president object created yet." << endl;
                }
                break;
            case 5:
                if (president) {
                    president->declareEmergency();
                } else {
                    cout << "No president object created yet." << endl;
                }
                break;
            case 6:
                if (president) {
                    string message;
                    cout << "Enter message: ";
                    getline(cin, message);
                    president->addressNation(message);
                } else {
                    cout << "No president object created yet." << endl;
                }
                break;
            case 7:
                cout << "Returning to Main Menu..." << endl;
                break;
            default:
                cout << "Invalid choice. Please try again." << endl;
                break;
        }
    } while (choice != 7);
}

int main() {
    LokSabha *lokSabha = nullptr;
    RajyaSabha *rajyaSabha = nullptr;
    President *president = nullptr;

    int choice;
    do {
        cout << "\nMain Menu:" << endl;
        cout << "1. Lok Sabha Menu" << endl;
        cout << "2. Rajya Sabha Menu" << endl;
        cout << "3. President Menu" << endl;
        cout << "4. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;
        cin.ignore();
        switch (choice) {
            case 1:
                lokSabhaMenu(lokSabha);
                break;
            case 2:
                rajyaSabhaMenu(rajyaSabha);
                break;
            case 3:
                presidentMenu(president);
                break;
            case 4:
                cout << "Exiting..." << endl;
                break;
            default:
                cout << "Invalid choice. Please try again." << endl;
                break;
        }
    } while (choice != 4);

    // Cleanup
    delete lokSabha;
    delete rajyaSabha;
    delete president;

    return 0;
}
